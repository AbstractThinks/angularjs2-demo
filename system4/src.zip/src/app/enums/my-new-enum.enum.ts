export enum MyNewEnum {
}
