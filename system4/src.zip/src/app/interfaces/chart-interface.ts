export interface ChartInterface {
	theme:string;
	chartType
}
