export interface UserInterface {
	name: string;
	code: string;
	phone: string;
	email: string;
	sex: string;
	married: string;
	education: string;
	politics: string;
	native: string;
	birthday: string;
	subject: string;
	description: string;
	educationExperience: string;
	trainExperience: string;
	achievement: string;
}
