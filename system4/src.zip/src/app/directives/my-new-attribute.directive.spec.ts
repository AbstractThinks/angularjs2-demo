import { MyNewAttributeDirective } from './my-new-attribute.directive';

describe('MyNewAttributeDirective', () => {
  it('should create an instance', () => {
    const directive = new MyNewAttributeDirective();
    expect(directive).toBeTruthy();
  });
});
