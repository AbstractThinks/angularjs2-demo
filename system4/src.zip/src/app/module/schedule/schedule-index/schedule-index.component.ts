import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-schedule-index',
  templateUrl: './schedule-index.component.html',
  styleUrls: ['./schedule-index.component.css']
})
export class ScheduleIndexComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
