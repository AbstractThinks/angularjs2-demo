import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resource-index',
  templateUrl: './resource-index.component.html',
  styleUrls: ['./resource-index.component.css']
})
export class ResourceIndexComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
