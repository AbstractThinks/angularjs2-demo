import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resource-mine',
  templateUrl: './resource-mine.component.html',
  styleUrls: ['./resource-mine.component.css']
})
export class ResourceMineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
